﻿using System;
using System.IO;


namespace TaskTrackingApp
{
    static class Program
    {
        static void Main( )
        {
            StartMenu start = new StartMenu();
            start.Greeting();
            start.MainMenu();
        }

    }
}
        
    
	